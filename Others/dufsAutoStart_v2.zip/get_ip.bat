@echo off
setlocal enabledelayedexpansion

:: 1. Check if dufs is running
tasklist | findstr /i "dufs" >nul
if errorlevel 1 (
    echo ======================================================
    echo  [WARNING] dufs is NOT running!
    echo  Please run start.bat first.
    echo ======================================================
    echo.
    echo Window will close in 3 seconds...
    timeout /t 3 >nul 2>&1
    exit /b
)

:: 2. Collect all active IPv4 addresses
set "TARGET_IP="
set "VM_172="
set "VM_192="
set "VM_10="
set "FALLBACK_IP="

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    for /f "tokens=1" %%b in ("%%a") do (
        set "CUR_IP=%%b"
        if not "!CUR_IP!"=="" if not "!CUR_IP!"=="127.0.0.1" (
            if not defined FALLBACK_IP set "FALLBACK_IP=!CUR_IP!"
            
            echo !CUR_IP! | findstr "^172\." >nul && (
                if not defined VM_172 set "VM_172=!CUR_IP!"
            )
            echo !CUR_IP! | findstr "^192\.168\." >nul && (
                if not defined TARGET_IP if not defined VM_192 set "VM_192=!CUR_IP!"
            )
            echo !CUR_IP! | findstr "^10\." >nul && (
                if not defined TARGET_IP if not defined VM_10 set "VM_10=!CUR_IP!"
            )
        )
    )
)

:: Priority: 172.x (WSL/Hyper-V) > 192.168.x (VMware/VBox/LAN) > 10.x > Fallback
if defined VM_172 (
    set "TARGET_IP=%VM_172%"
) else if defined VM_192 (
    set "TARGET_IP=%VM_192%"
) else if defined VM_10 (
    set "TARGET_IP=%VM_10%"
) else (
    set "TARGET_IP=%FALLBACK_IP%"
)

if defined TARGET_IP (
    <nul set /p="http://%TARGET_IP%:5000/" | clip
    echo ======================================================
    echo  [OK] Copied to clipboard: http://%TARGET_IP%:5000/
    echo ======================================================
    echo.
    echo Available addresses on this machine:
    for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
        for /f "tokens=1" %%b in ("%%a") do (
            set "CUR_IP=%%b"
            if not "!CUR_IP!"=="" if not "!CUR_IP!"=="127.0.0.1" (
                if "!CUR_IP!"=="!TARGET_IP!" (
                    echo    [*] http://!CUR_IP!:5000/  [Copied]
                ) else (
                    echo    [ ] http://!CUR_IP!:5000/
                )
            )
        )
    )
) else (
    echo ======================================================
    echo  [ERROR] No active network adapter IPv4 found.
    echo  Please check your network connections.
    echo ======================================================
)

echo.
echo Window will close in 5 seconds...
timeout /t 5 >nul 2>&1
