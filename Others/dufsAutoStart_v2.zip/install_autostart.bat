@echo off
setlocal
cd /d "%~dp0"
set "PATH=%~dp0;%PATH%"

:: 1. Check nircmd
where nircmd.exe >nul 2>&1
if errorlevel 1 (
    echo ======================================================
    echo  [ERROR] nircmd.exe not found in system PATH!
    echo  Please ensure nircmd is installed and added to PATH.
    echo ======================================================
    echo.
    pause
    exit /b 1
)

:: 2. Resolve root share directory and current script directory dynamically
for %%i in ("%~dp0..") do (
    set "ROOT_DIR=%%~fi"
    set "DIR_NAME=%%~nxi"
)
for %%i in ("%~dp0.") do set "SCRIPT_DIR=%%~nxi"

:: 3. Create completely silent autostart shortcut in Windows Startup folder
nircmd.exe shortcut "nircmd.exe" "~$folder.startup$" "Dufs_%DIR_NAME%" "exec hide dufs -p 5000 -A --hidden %SCRIPT_DIR%" "" "" "min" "%ROOT_DIR%"

if %errorlevel% equ 0 (
    echo ======================================================
    echo  [OK] Autostart shortcut installed successfully!
    echo  - Mode: Completely silent [0 console window]
    echo  - Target Folder:   %DIR_NAME%
    echo  - Directory:       %ROOT_DIR%
    echo  - Shortcut Name:   Dufs_%DIR_NAME%.lnk
    echo ======================================================
    echo.
    echo The service will start automatically when Windows logs in.
) else (
    echo ======================================================
    echo  [ERROR] Failed to create autostart shortcut.
    echo ======================================================
)

echo.
pause
