@echo off
setlocal
cd /d "%~dp0.."
set "PATH=%~dp0;%PATH%"

:: 1. Check if nircmd and dufs are available (bundled or system PATH)
where nircmd.exe >nul 2>&1
if errorlevel 1 (
    echo ======================================================
    echo  [ERROR] nircmd.exe not found!
    echo  Please ensure nircmd.exe is in the script folder or PATH.
    echo ======================================================
    echo.
    pause
    exit /b 1
)

where dufs >nul 2>&1
if errorlevel 1 (
    echo ======================================================
    echo  [ERROR] dufs.exe not found!
    echo  Please ensure dufs.exe is in the script folder or PATH.
    echo ======================================================
    echo.
    pause
    exit /b 1
)

:: 2. Stop any existing dufs instance
nircmd.exe killprocess dufs.exe >nul 2>&1

:: 3. Configure port (default 5000, or %1 if provided)
set "PORT=5000"
if not "%~1"=="" set "PORT=%~1"

:: 4. Start dufs in background (hidden window, automatically hide script folder)
for %%i in ("%~dp0.") do set "SCRIPT_DIR=%%~nxi"
nircmd.exe exec hide dufs -p %PORT% -A --hidden "%SCRIPT_DIR%"

:: 5. Verification
timeout /t 1 >nul 2>&1
tasklist | findstr /i "dufs" >nul
for %%i in ("%~dp0..") do set "DIR_NAME=%%~nxi"
if %errorlevel% equ 0 (
    echo ======================================================
    echo  [OK] dufs started successfully for [%DIR_NAME%]!
    echo  - Shared Directory: %cd%
    echo  - Service Port:     %PORT%
    echo  - Local URL:        http://localhost:%PORT%/
    echo ======================================================
    echo.
    echo Tip: Double-click get_ip.bat to copy VM access address.
) else (
    echo ======================================================
    echo  [WARNING] dufs process was not detected.
    echo  Please check if port %PORT% is already occupied.
    echo ======================================================
)

echo.
echo Window will close in 3 seconds...
timeout /t 3 >nul 2>&1
