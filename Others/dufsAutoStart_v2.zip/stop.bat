@echo off
setlocal
set "PATH=%~dp0;%PATH%"

tasklist | findstr /i "dufs" >nul
if errorlevel 1 (
    echo [INFO] dufs is not running.
    echo Window will close in 2 seconds...
    timeout /t 2 >nul 2>&1
    exit /b
)

where nircmd.exe >nul 2>&1
if %errorlevel% equ 0 (
    nircmd.exe killprocess dufs.exe >nul 2>&1
) else (
    taskkill /f /im dufs.exe >nul 2>&1
)

:: Double check with taskkill if needed
tasklist | findstr /i "dufs" >nul
if %errorlevel% equ 0 (
    taskkill /f /im dufs.exe >nul 2>&1
)

echo ======================================================
echo  [OK] dufs has been stopped.
echo ======================================================
echo.
echo Window will close in 2 seconds...
timeout /t 2 >nul 2>&1
