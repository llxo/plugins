@echo off
setlocal

for %%i in ("%~dp0..") do set "DIR_NAME=%%~nxi"

set "LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Dufs_%DIR_NAME%.lnk"
set "OLD_LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\VMShare_Dufs.lnk"

set "REMOVED=0"

if exist "%LNK%" (
    del /f /q "%LNK%"
    echo [OK] Removed Dufs_%DIR_NAME%.lnk from Startup folder.
    set "REMOVED=1"
)

if exist "%OLD_LNK%" (
    del /f /q "%OLD_LNK%"
    echo [OK] Removed legacy VMShare_Dufs.lnk from Startup folder.
    set "REMOVED=1"
)

if "%REMOVED%"=="0" (
    echo [INFO] No autostart shortcut found for [%DIR_NAME%].
)

echo.
pause
